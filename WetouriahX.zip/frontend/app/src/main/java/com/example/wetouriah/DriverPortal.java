package com.example.wetouriah;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class DriverPortal extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driver_portal);
    }
}