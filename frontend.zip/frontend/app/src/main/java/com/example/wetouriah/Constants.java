package com.example.wetouriah;

public class Constants {
    public static final String SERVER_IP_ADDRESS = "192.168.56.1"; // Replace with your actual IP address

}
