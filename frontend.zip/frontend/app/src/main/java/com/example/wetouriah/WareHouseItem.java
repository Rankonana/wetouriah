package com.example.wetouriah;

public class WareHouseItem {

    String address;

    public WareHouseItem(String address) {
        this.address = address;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
